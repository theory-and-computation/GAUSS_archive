#-----------------#
# extr_cv_coor.py #
#-----------------#
import MDAnalysis as mda
import numpy as np
import sys
import os

## current job id
#curr_job_id= os.environ.get('curr_job_id')

# Universe
topo = "../components/topo/alad-wats_cross-term.psf"
traj = f"output/equ.dcd"
print(traj)
u = mda.Universe(topo, traj)

# CV atom indices
atom_ids = [sys.argv[i] for i in range(1, len(sys.argv))]
atom_ids_str = ' '.join(map(str, atom_ids))
atoms_sel = u.select_atoms(f"index {atom_ids_str}") 

# Extract coordinates
with open(f"output/equ.cv_coor.txt", "w") as f:
    header_string = ' '.join(['{atom_' + f'{int(i):03d}' + '_x} {atom_' + f'{int(i):03d}' + '_y} {atom_' f'{int(i):03d}' + '_z}' for i in atom_ids])
    f.write('{ timestep } ' + header_string + ' \n')
    for ts in u.trajectory:
        coor = atoms_sel.positions
        coor_string = '   '.join([f'{x:>10.5f}' for a in coor for x in a])
        f.write(f' {ts.frame:>10}   ' + coor_string + '\n')



