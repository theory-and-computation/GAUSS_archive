#-------------#
# get_vel.tcl #
#-------------#

mol new ../components/topo/alad-wats_cross-term.psf type psf waitfor all
mol addfile output/equ.dcd type dcd waitfor all

set molcoords [molinfo top]

mol new ../components/topo/alad-wats_cross-term.psf type psf waitfor all
mol addfile output/equ.veldcd type dcd waitfor all

set molvel [molinfo top]

set nfcoords [molinfo $molcoords get numframes]
set nfvel    [molinfo $molvel    get numframes]
if {$nfcoords != $nfvel} {
    error "Frame mismatch: coords=$nfcoords, veldcd=$nfvel"
}

for {set f 0} {$f < $nfcoords} {incr f} {
    set selV [atomselect $molvel "all" frame $f]
    set selC [atomselect $molcoords "all" frame $f]

    set vvals [$selV get {x y z}]
    $selC set {vx vy vz} $vvals

    $selV delete
    $selC delete
}

mol top $molcoords

set cv [atomselect top "index 6 8 14 16"]

set output [open cv_vel.dat w]
puts $output [format "%13s%13s%13s%13s%13s%13s%13s%13s%13s%13s%13s%13s%13s" \
	"{frame}" \
	" {atom_1_vx}" " {atom_1_vy}" " {atom_1_vz}" \
	" {atom_2_vx}" " {atom_2_vy}" " {atom_2_vz}" \
	" {atom_3_vx}" " {atom_3_vy}" " {atom_3_vz}" \
	" {atom_4_vx}" " {atom_4_vy}" " {atom_4_vz}"
]

set n_frames [molinfo top get numframes]
for {set fr 0} {$fr < $n_frames} {incr fr} {
    $cv frame $fr
    set vels [$cv get {vx vy vz}]
	puts $output [format "%12d %12.5f %12.5f %12.5f %12.5f %12.5f %12.5f %12.5f %12.5f %12.5f %12.5f %12.5f %12.5f" \
		$fr \
		[lindex [lindex $vels 0] 0] [lindex [lindex $vels 0] 1] [lindex [lindex $vels 0] 2] \
		[lindex [lindex $vels 1] 0] [lindex [lindex $vels 1] 1] [lindex [lindex $vels 1] 2] \
		[lindex [lindex $vels 2] 0] [lindex [lindex $vels 2] 1] [lindex [lindex $vels 2] 2] \
		[lindex [lindex $vels 3] 0] [lindex [lindex $vels 3] 1] [lindex [lindex $vels 3] 2]
	]
}
close $output
$cv delete

