#----------------------------#
# calc_colvar_forces_tcl.tcl #
#----------------------------#

# extract model data from file ----------------------------#
# executed at initialization of NAMD job ------------------#
puts "\nEXTRACTING DATA\n"
set model [open "model_data.txt" r]
set x_arr {}
set f_arr {}
while {[gets $model line] >= 0} {
    set data [split $line]
    if {[llength $data] == 2} {
        lappend x_arr [lindex $data 0]
        lappend f_arr [lindex $data 1]
    } else {
		puts stderr "Warning: skipping malformed line: $line"
	}
}
#----------------------------------------------------------#


# main procedure ------------------------------------------#
# called at each timestep ---------------------------------#
proc calc_colvar_forces { step } {
	global x_arr
	global f_arr
	set x [expr floor([cv colvar IonDistance value] * 100) / 100]
	set lo 0
	set hi [expr {[llength $x_arr] - 1}]
	while {$lo <= $hi} {
		# when converged to adjacent indices, choose closer index
		if {[expr $hi - $lo] == 1} { 
			set dlo [expr {abs($x - [lindex $x_arr $lo])}]
			set dhi [expr {abs($x - [lindex $x_arr $hi])}]
			set closer_id [expr {($dlo < $dhi) * $lo + ($dlo >= $dhi) * $hi}]
			set f [lindex $f_arr $closer_id]
			break
		# else, continue search
		} else {
			set mid [expr {int(($lo + $hi) / 2)}]
			set x_mid [expr floor([lindex $x_arr $mid] * 100) / 100]
			# bullseye
			if {$x == $x_mid} {
				set f [lindex $f_arr $mid]
				break
			} elseif {$x < $x_mid} {
				set hi $mid
			} else {
				set lo $mid
			}
		}
	}

    cv colvar IonDistance addforce $f
	puts "$step   cv: $x   bias force: $f"
}
#----------------------------------------------------------#

